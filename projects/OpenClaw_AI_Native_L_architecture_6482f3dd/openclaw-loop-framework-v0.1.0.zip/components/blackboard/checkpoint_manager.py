"""Full and incremental checkpoint management."""

from __future__ import annotations

import json
from enum import StrEnum
from pathlib import Path
from typing import Any, Mapping

from .atomic_writer import atomic_write

JsonObject = dict[str, Any]


class CheckpointLevel(StrEnum):
    FULL = "full"
    INCREMENTAL = "incremental"


class CheckpointManager:
    """Manage full checkpoints and ordered incremental checkpoint patches."""

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def create_full_checkpoint(self, state: Mapping[str, Any]) -> Path:
        """Persist a full state snapshot and reset incremental history."""

        self._clear_incrementals()
        path = self.root / "full.json"
        self._write_json(path, dict(state))
        return path

    def create_incremental_checkpoint(self, patch: Mapping[str, Any]) -> Path:
        """Persist an incremental patch after the current latest checkpoint."""

        sequence = self._next_incremental_sequence()
        path = self.root / f"incremental-{sequence:06d}.json"
        self._write_json(path, dict(patch))
        return path

    def restore(self) -> JsonObject:
        """Restore state by applying all incrementals over the full checkpoint."""

        full_path = self.root / "full.json"
        if not full_path.exists():
            raise FileNotFoundError(f"missing full checkpoint: {full_path}")

        state = self._read_json(full_path)
        for path in self._incremental_paths():
            patch = self._read_json(path)
            state = self._deep_merge(state, patch)
        return state

    def _write_json(self, path: Path, payload: Mapping[str, Any]) -> None:
        encoded = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        atomic_write(path, encoded)

    def _read_json(self, path: Path) -> JsonObject:
        with path.open("r", encoding="utf-8") as file:
            loaded = json.load(file)
        if not isinstance(loaded, dict):
            raise ValueError(f"checkpoint must contain a JSON object: {path}")
        return loaded

    def _clear_incrementals(self) -> None:
        for path in self._incremental_paths():
            path.unlink()

    def _incremental_paths(self) -> list[Path]:
        return sorted(self.root.glob("incremental-*.json"))

    def _next_incremental_sequence(self) -> int:
        paths = self._incremental_paths()
        if not paths:
            return 1
        return int(paths[-1].stem.rsplit("-", 1)[1]) + 1

    def _deep_merge(self, base: JsonObject, patch: Mapping[str, Any]) -> JsonObject:
        merged = dict(base)
        for key, value in patch.items():
            existing = merged.get(key)
            if isinstance(existing, dict) and isinstance(value, Mapping):
                merged[key] = self._deep_merge(existing, value)
            else:
                merged[key] = value
        return merged
