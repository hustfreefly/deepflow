"""Small Blackboard interface backed by atomic JSON persistence."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping

from .atomic_writer import atomic_write
from .checkpoint_manager import CheckpointManager


class Blackboard:
    """Persist and checkpoint JSON-compatible Blackboard state."""

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.state_path = self.root / "state.json"
        self.checkpoints = CheckpointManager(self.root / "checkpoints")

    def write_state(self, state: Mapping[str, Any]) -> None:
        encoded = json.dumps(dict(state), sort_keys=True, separators=(",", ":"))
        atomic_write(self.state_path, encoded)

    def read_state(self) -> dict[str, Any]:
        with self.state_path.open("r", encoding="utf-8") as file:
            loaded = json.load(file)
        if not isinstance(loaded, dict):
            raise ValueError(f"blackboard state must be a JSON object: {self.state_path}")
        return loaded

    def full_checkpoint(self, state: Mapping[str, Any] | None = None) -> Path:
        return self.checkpoints.create_full_checkpoint(state or self.read_state())

    def incremental_checkpoint(self, patch: Mapping[str, Any]) -> Path:
        return self.checkpoints.create_incremental_checkpoint(patch)

    def restore_checkpoint(self) -> dict[str, Any]:
        return self.checkpoints.restore()
