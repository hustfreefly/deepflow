"""Atomic file writes for Blackboard state."""

from __future__ import annotations

import fcntl
import os
import tempfile
from pathlib import Path
from typing import Union

WritableData = Union[str, bytes, bytearray, memoryview]


def _to_bytes(data: WritableData) -> bytes:
    if isinstance(data, str):
        return data.encode("utf-8")
    return bytes(data)


def _fsync_directory(directory: Path) -> None:
    dir_fd = os.open(directory, os.O_RDONLY)
    try:
        os.fsync(dir_fd)
    finally:
        os.close(dir_fd)


def atomic_write(path: str | Path, data: WritableData) -> None:
    """Write data atomically using a temp file followed by an atomic rename.

    The temp file is created in the target directory so `os.replace` stays on
    the same filesystem. A sidecar lock serializes writers across processes.
    """

    target = Path(path)
    directory = target.parent
    directory.mkdir(parents=True, exist_ok=True)

    payload = _to_bytes(data)
    lock_path = directory / f".{target.name}.lock"
    temp_path: Path | None = None

    with lock_path.open("a+b") as lock_file:
        fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX)
        try:
            fd, temp_name = tempfile.mkstemp(
                prefix=f".{target.name}.",
                suffix=".tmp",
                dir=str(directory),
            )
            temp_path = Path(temp_name)

            with os.fdopen(fd, "wb") as temp_file:
                temp_file.write(payload)
                temp_file.flush()
                os.fsync(temp_file.fileno())

            os.replace(temp_path, target)
            _fsync_directory(directory)
        finally:
            if temp_path is not None:
                try:
                    temp_path.unlink()
                except FileNotFoundError:
                    pass
            fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)
